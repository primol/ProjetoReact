

import React from 'react';
import { View, Text } from 'react-native';

class TelaEX extends React.Component {
  render() {
    const { filme } = this.props.route.params;

    return (
      <View style={{ flex: 1, padding: 20 }}>
        <Text style={{ fontSize: 24, fontWeight: 'bold' }}>{filme.title}</Text>
        <Text style={{ marginTop: 10 }}>{filme.overview}</Text>
        <Text style={{ marginTop: 10, color: 'gray' }}>
          Popularidade: {filme.popularity}
        </Text>
        <Text style={{ marginTop: 10, color: 'gray' }}>
          Nota: {filme.vote_average}
        </Text>
      </View>
    );
  }
}

export default TelaEX;
