

const filmes = [
  {
    id: '1',
    title: 'Vingadores: Ultimato',
    overview: 'Os Vingadores se unem para desfazer as ações de Thanos.',

  },
  {
    id: '2',
    title: 'Homem-Aranha: Sem Volta Para Casa',
    overview: 'Peter Parker lida com as consequências de sua identidade revelada.',

  },
  {
    id: '3',
    title: 'Interestelar',
    overview: 'Um grupo de astronautas viaja através de um buraco de minhoca.',

  }
];

export default filmes;
