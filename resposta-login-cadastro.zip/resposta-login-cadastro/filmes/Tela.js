// screens/TelaFilmes.js

import React from 'react';
import { View, Text, Button, ScrollView } from 'react-native';
import { Card, Paragraph } from 'react-native-paper';
import filmes from '../filmes/Filmes';

class TelaFilmes extends React.Component {
  render() {
    return (
      <ScrollView style={{ padding: 10 }}>
        <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Lista de Filmes</Text>

        {filmes.map(filme => (
          <Card key={filme.id} style={{ marginVertical: 10 }}>
            <Card.Title title={filme.title} />
            <Card.Content>
              <Paragraph numberOfLines={3}>{filme.overview}</Paragraph>
            </Card.Content>
            <Card.Actions>
              <Button
                title="Ver Detalhes"
                onPress={() =>
                  this.props.navigation.navigate('DetalhesFilme', { filme })
                }
              />
            </Card.Actions>
          </Card>
        ))}
      </ScrollView>
    );
  }
}

export default TelaFilmes;
