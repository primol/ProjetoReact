import React, { useState, useEffect } from 'react';
import {
  TextInput, Text, View, Button, StyleSheet,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Card, Paragraph } from 'react-native-paper';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// ------------------- TELA DE LOGIN -------------------
function Principal({ navigation }) {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [pontosPPT, setPontosPPT] = useState(0);
  const [pontosAdv, setPontosAdv] = useState(0);
  const [logado, setLogado] = useState(false);
  const [loading, setLoading] = useState(false);

  async function ler() {
    if (!usuario || !senha) {
      alert('Preencha usuário e senha!');
      return;
    }
    try {
      setLoading(true);
      const senhaArmazenada = await AsyncStorage.getItem(usuario);
      if (senhaArmazenada !== null) {
        if (senhaArmazenada === senha) {
          // Buscar pontuações dos dois jogos
          const pptStr = await AsyncStorage.getItem(`${usuario}_ppt_pontos`);
          const advStr = await AsyncStorage.getItem(`${usuario}_adivinhacao_pontos`);
          setPontosPPT(pptStr ? parseInt(pptStr, 10) : 0);
          setPontosAdv(advStr ? parseInt(advStr, 10) : 0);
          setLogado(true);
        } else {
          alert('Senha incorreta!');
        }
      } else {
        alert('Usuário não encontrado!');
      }
    } catch (e) {
      console.log(e);
    }
    setLoading(false);
  }

  function logout() {
    setUsuario('');
    setSenha('');
    setPontosPPT(0);
    setPontosAdv(0);
    setLogado(false);
  }

  if (!logado) {
    return (
      <View style={styles.container}>
        <Text>Usuário:</Text>
        <TextInput
          style={styles.input}
          value={usuario}
          onChangeText={setUsuario}
          autoCapitalize="none"
        />
        <Text>Senha:</Text>
        <TextInput
          style={styles.input}
          value={senha}
          onChangeText={setSenha}
          secureTextEntry
        />
        <Button title={loading ? 'Carregando...' : 'Logar'} onPress={ler} />
      </View>
    );
  }

 return (
    <View style={styles.container}>
      <Text style={{ fontSize: 18 }}>Bem-vindo, {usuario}!</Text>

      <Card style={styles.card}>
        <Card.Title title="Pedra, Papel e Tesoura" />
        <Card.Content>
          <Paragraph>Jogue contra o NPC!</Paragraph>
        </Card.Content>
        <Card.Actions>
          <Button
            title="Jogar"
            onPress={() => navigation.navigate('PedraPapelTesouraStack', { usuario })}
          />
        </Card.Actions>
      </Card>

      <Card style={styles.card}>
        <Card.Title title="Jogo de Adivinhação" />
        <Card.Content>
          <Paragraph>Adivinhe o número secreto.</Paragraph>
        </Card.Content>
        <Card.Actions>
          <Button
            title="Jogar"
            onPress={() => navigation.navigate('AdivinhacaoStack', { usuario })}
          />
        </Card.Actions>
      </Card>

      <Button title="Ver Scoreboard" onPress={() => navigation.navigate('Scoreboard')} />

      <View style={{ marginTop: 10 }}>
        <Button title="Logout" onPress={logout} color="red" />
      </View>
    </View>
  );
}

// ------------------- TELA DE CADASTRO -------------------
function Cadastro() {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');

  async function gravar() {
    if (!user || !password) {
      alert('Preencha os campos');
      return;
    }
    try {
      await AsyncStorage.setItem(user, password);
      // inicializa pontuações com zero
      await AsyncStorage.setItem(`${user}_ppt_pontos`, '0');
      await AsyncStorage.setItem(`${user}_adivinhacao_pontos`, '0');
      alert('Usuário criado com sucesso!');
      setUser('');
      setPassword('');
    } catch (e) {
      alert('Erro ao cadastrar');
    }
  }

  return (
    <View style={styles.container}>
      <Text>Cadastrar Usuário:</Text>
      <TextInput
        style={styles.input}
        value={user}
        onChangeText={setUser}
        autoCapitalize="none"
      />
      <Text>Cadastrar Senha:</Text>
      <TextInput
        style={styles.input}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="Cadastrar" onPress={gravar} />
    </View>
  );
}

// ------------------- JOGO PPT -------------------
function PedraPapelTesouraScreen({ route }) {
  const usuario = route.params?.usuario || 'convidado';
  const opcoes = ['Pedra', 'Papel', 'Tesoura'];

  const [vitorias, setVitorias] = useState(0);
  const [derrotas, setDerrotas] = useState(0);
  const [empates, setEmpates] = useState(0);
  const [jogadaNPC, setJogadaNPC] = useState('');
  const [mensagem, setMensagem] = useState('Escolha sua jogada.');

  async function adicionarPontosPPT(pontosGanhos) {
    try {
      const chave = `${usuario}_ppt_pontos`;
      const ptsStr = await AsyncStorage.getItem(chave);
      const pts = ptsStr ? parseInt(ptsStr, 10) : 0;
      const novos = pts + pontosGanhos;
      await AsyncStorage.setItem(chave, novos.toString());
    } catch (e) {
      console.log('Erro ao salvar pontos PPT:', e);
    }
  }

  function reset() {
    setVitorias(0);
    setDerrotas(0);
    setEmpates(0);
    setJogadaNPC('');
    setMensagem('Novo jogo. Escolha sua jogada.');
  }

  function jogar(escolha) {
    const npc = opcoes[Math.floor(Math.random() * 3)];
    setJogadaNPC(npc);

    if (npc === escolha) {
      setEmpates((emp) => emp + 1);
      setMensagem('Empate.');
      return;
    }

    const ganhou =
      (escolha === 'Pedra' && npc === 'Tesoura') ||
      (escolha === 'Papel' && npc === 'Pedra') ||
      (escolha === 'Tesoura' && npc === 'Papel');

    if (ganhou) {
      const nv = vitorias + 1;
      setVitorias(nv);
      if (nv === 3) {
        setMensagem('Você venceu 3 vezes! +1 ponto.');
        adicionarPontosPPT(1);
        reset();
        return;
      }
      setMensagem('Você ganhou.');
    } else {
      const nd = derrotas + 1;
      setDerrotas(nd);
      if (nd === 3) {
        setMensagem('O NPC venceu 3 vezes.');
        reset();
        return;
      }
      setMensagem('Você perdeu.');
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Pedra, Papel ou Tesoura</Text>
      <Text style={styles.placar}>
        Você {vitorias} x {derrotas} NPC | Empates: {empates}
      </Text>

      <View style={styles.botoes}>
        <View style={styles.btn}>
          <Button title="Pedra" onPress={() => jogar('Pedra')} />
        </View>
        <View style={styles.btn}>
          <Button title="Papel" onPress={() => jogar('Papel')} />
        </View>
        <View style={styles.btn}>
          <Button title="Tesoura" onPress={() => jogar('Tesoura')} />
        </View>
      </View>

      {jogadaNPC !== '' && (
        <Text style={styles.info}>NPC jogou: {jogadaNPC}</Text>
      )}
      <Text style={styles.mensagem}>{mensagem}</Text>
    </View>
  );
}

// ------------------- JOGO ADIVINHAÇÃO -------------------
function AdivinhacaoScreen({ route }) {
  const usuario = route.params?.usuario || 'convidado';

  const [numeroSecreto, setNumeroSecreto] = useState(null);
  const [palpite, setPalpite] = useState('');
  const [tentativas, setTentativas] = useState(0);
  const [mensagem, setMensagem] = useState('Tente adivinhar o número de 1 a 100.');
  const [ultDiferenca, setUltDiferenca] = useState(null);

  useEffect(() => {
    resetGame();
  }, []);

  function resetGame() {
    const secreto = Math.floor(Math.random() * 100) + 1;
    setNumeroSecreto(secreto);
    setPalpite('');
    setTentativas(0);
    setMensagem('Tente adivinhar o número de 1 a 100.');
    setUltDiferenca(null);
  }

  async function adicionarPontosAdivinhacao(pontosGanhos) {
    try {
      const chave = `${usuario}_adivinhacao_pontos`;
      const ptsStr = await AsyncStorage.getItem(chave);
      const pts = ptsStr ? parseInt(ptsStr, 10) : 0;
      const novos = pts + pontosGanhos;
      await AsyncStorage.setItem(chave, novos.toString());
    } catch (e) {
      console.log('Erro ao salvar pontos adivinhação:', e);
    }
  }

  function handlePalpite() {
    const n = parseInt(palpite, 10);
    if (isNaN(n) || n < 1 || n > 100) {
      setMensagem('Informe um número válido entre 1 e 100.');
      return;
    }
    const diff = Math.abs(n - numeroSecreto);
    setTentativas((t) => t + 1);

    if (n === numeroSecreto) {
      // Acertou
      const ttotal = tentativas + 1;
      const pontosGanhos = Math.max(1, Math.floor(100 / ttotal));
      setMensagem(`Parabéns! Você acertou em ${ttotal} tentativas e ganhou ${pontosGanhos} ponto(s).`);
      adicionarPontosAdivinhacao(pontosGanhos);
      setTimeout(() => {
        resetGame();
      }, 2000);
    } else {
      let dica = '';
      if (ultDiferenca !== null) {
        if (diff < ultDiferenca) {
          dica = 'Você está mais perto.';
        } else if (diff > ultDiferenca) {
          dica = 'Você está mais longe.';
        } else {
          dica = 'Você está na mesma distância.';
        }
      }
      if (diff > 50) {
        dica += ' Muito longe!';
      } else if (diff <= 10) {
        dica += ' Quase lá!';
      }

      setMensagem(`Errado. ${dica}`);
      setUltDiferenca(diff);
    }

    setPalpite('');
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Jogo de Adivinhação</Text>
      <Text style={styles.info}>Tentativas: {tentativas}</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu palpite"
        keyboardType="numeric"
        value={palpite}
        onChangeText={setPalpite}
      />
      <Button title="Palpitar" onPress={handlePalpite} />
      <Text style={styles.mensagem}>{mensagem}</Text>
      <View style={{ marginTop: 10 }}>
        <Button title="Reiniciar Jogo" onPress={resetGame} />
      </View>
    </View>
  );
}

// ------------------- SCOREBOARD -------------------
function Scoreboard() {
  const [ranking, setRanking] = useState([]);

  useEffect(() => {
    async function buscarDados() {
      const chaves = await AsyncStorage.getAllKeys();
      const ptsKeys = chaves.filter(
        (k) => k.includes('_ppt_pontos') || k.includes('_adivinhacao_pontos')
      );
      const pares = await AsyncStorage.multiGet(ptsKeys);
      const lista = pares.map(([k, v]) => {
        const parts = k.split('_');
        const usuario = parts[0];
        const tipo = parts[1] === 'ppt' ? 'PPT' : 'Adivinhação';
        const pontos = v ? parseInt(v, 10) : 0;
        return { usuario, tipo, pontos };
      });
      // Ordenar por pontos decrescentes
      lista.sort((a, b) => b.pontos - a.pontos);
      setRanking(lista);
    }
    buscarDados();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>🏆 Scoreboard</Text>
      {ranking.length === 0 ? (
        <Text>Nenhum jogo pontuado ainda.</Text>
      ) : (
        ranking.map((item, idx) => (
          <Text key={idx}>
            {idx + 1}. {item.usuario} — {item.tipo}: {item.pontos} pt(s)
          </Text>
        ))
      )}
    </View>
  );
}

// ------------------- NAVEGAÇÃO -------------------
function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Principal" component={Principal} options={{ title: 'Início' }} />
      <Stack.Screen name="PedraPapelTesouraStack" component={PedraPapelTesouraScreen} options={{ title: 'PPT' }} />
      <Stack.Screen name="AdivinhacaoStack" component={AdivinhacaoScreen} options={{ title: 'Adivinhação' }} />
      <Stack.Screen name="Scoreboard" component={Scoreboard} options={{ title: 'Ranking' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen
          name="Login"
          component={HomeStack}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="login" color={color} size={size} />
            ),
          }}
        />
        <Tab.Screen
          name="Criar Usuário"
          component={Cadastro}
          options={{
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="account-plus" color={color} size={size} />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

// ------------------- ESTILOS -------------------
const styles = StyleSheet.create({
  container: {
    flex: 1, padding: 20, justifyContent: 'center', backgroundColor: '#f0f0f0',
  },
  input: {
    borderWidth: 1, borderColor: '#ccc', padding: 8, marginVertical: 6, borderRadius: 5,
  },
  card: {
    marginVertical: 10,
    backgroundColor: '#fff',
    elevation: 3,
  },
  titulo: {
    fontSize: 22, fontWeight: 'bold', marginBottom: 10, textAlign: 'center',
  },
  info: {
    fontSize: 16, marginBottom: 10,
  },
  botoes: {
    flexDirection: 'row', width: '90%', justifyContent: 'space-between', marginVertical: 8,
  },
  btn: { flex: 1, marginHorizontal: 4 },
  placar: {
    fontSize: 16, marginBottom: 6,
  },
  mensagem: {
    marginTop: 20, fontSize: 18, textAlign: 'center',
  },
});

