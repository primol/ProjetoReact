import React, { useState, useEffect } from 'react';
import {
  TextInput, Text, View, TouchableOpacity, Image, ScrollView, FlatList, StyleSheet
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Card } from 'react-native-paper';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// ------------------- TELA PRINCIPAL -------------------
function Principal({ navigation }) {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [logado, setLogado] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pesquisa, setPesquisa] = useState('');
  const [deckSelecionado, setDeckSelecionado] = useState(null);

  const decksMaisUsados = [
    {
      id: '1',
      nome: 'Deck 2.6 Hog Cycle',
      img: require('./imagens_cartas/hogrider.png'),
      cartas: Array(8).fill({ nome: 'Hog Rider', img: require('./imagens_cartas/hogrider.png') }),
    },
    {
      id: '2',
      nome: 'Deck Log Bait',
      img: require('./imagens_cartas/hogrider.png'),
      cartas: Array(8).fill({ nome: 'Hog Rider', img: require('./imagens_cartas/hogrider.png') }),
    },
    {
      id: '3',
      nome: 'Deck Golem Beatdown',
      img: require('./imagens_cartas/hogrider.png'),
      cartas: Array(8).fill({ nome: 'Hog Rider', img: require('./imagens_cartas/hogrider.png') }),
    },
  ];

  const decksFiltrados = decksMaisUsados.filter((d) =>
    d.nome.toLowerCase().includes(pesquisa.toLowerCase())
  );

  async function ler() {
    if (!usuario || !senha) {
      alert('Preencha usuário e senha!');
      return;
    }
    try {
      setLoading(true);
      const senhaArmazenada = await AsyncStorage.getItem(usuario);
      if (senhaArmazenada !== null) {
        if (senhaArmazenada === senha) {
          await AsyncStorage.setItem('usuarioLogado', 'true');
          setLogado(true);
        } else {
          alert('Senha incorreta!');
        }
      } else {
        alert('Usuário não encontrado! Tente criar uma conta.');
      }
    } catch (e) {
      alert('Erro ao tentar logar.');
    }
    setLoading(false);
  }

  async function logout() {
    await AsyncStorage.removeItem('usuarioLogado');
    setUsuario('');
    setSenha('');
    setLogado(false);
  }

  // Verifica login salvo
  useEffect(() => {
    const checarLogin = async () => {
      const logadoLocal = await AsyncStorage.getItem('usuarioLogado');
      if (logadoLocal) setLogado(true);
    };
    checarLogin();
  }, []);

  // ------------------- TELA DE LOGIN -------------------
  if (!logado) {
    return (
      <View style={[styles.container, styles.loginBackground]}>
        <Image 
          source={{ uri: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/ee/Clash_Royale_logo.svg/1200px-Clash_Royale_logo.svg.png' }}
          style={styles.gameLogo}
        />
        <View style={styles.loginCard}>
          <Text style={styles.loginTitle}>BEM-VINDO AO ROYALE!</Text>
          <Text style={styles.label}>NOME DE JOGADOR:</Text>
          <TextInput
            style={styles.inputClash}
            value={usuario}
            onChangeText={setUsuario}
            placeholder="Digite seu usuário..."
            placeholderTextColor="#a09070"
          />
          <Text style={styles.label}>SENHA SECRETA:</Text>
          <TextInput
            style={styles.inputClash}
            value={senha}
            onChangeText={setSenha}
            placeholder="Digite sua senha..."
            placeholderTextColor="#a09070"
            secureTextEntry
          />
          <TouchableOpacity style={styles.buttonClashPrimary} onPress={ler}>
            <Text style={styles.buttonText}>{loading ? 'CARREGANDO...' : 'ENTRAR NA ARENA'}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // ------------------- TELA PRINCIPAL APÓS LOGIN -------------------
  return (
    <View style={styles.container}>
      <Text style={styles.tituloClash}>DECKS MAIS USADOS NO MOMENTO</Text>

      <TextInput
        style={styles.inputClashSearch}
        placeholder="⚔️ Pesquisar deck..."
        placeholderTextColor="#a09070"
        value={pesquisa}
        onChangeText={setPesquisa}
      />

      <FlatList
        data={decksFiltrados}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card style={styles.cardClash}>
            <TouchableOpacity onPress={() =>
              setDeckSelecionado(deckSelecionado === item.id ? null : item.id)
            }>
              <View style={styles.deckContainer}>
                <Image source={item.img} style={styles.deckImgClash} />
                <Text style={styles.deckNomeClash}>{item.nome}</Text>
                <Image 
                  source={{ uri: 'https://static.wikia.nocookie.net/clashroyale/images/0/07/ElixirIcon.png' }}
                  style={styles.elixirIcon}
                />
                <Text style={styles.elixirText}>3.0</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.buttonClashSecondary}
              onPress={() => alert(`Você curtiu o ${item.nome}!`)} 
            >
              <Text style={styles.buttonTextSmall}>CURTIR DECK ❤️</Text>
            </TouchableOpacity>

            {deckSelecionado === item.id && (
              <View style={styles.cartasContainer}>
                {item.cartas.map((carta, index) => (
                  <View key={index} style={styles.carta}>
                    <Image source={carta.img} style={styles.cartaImgClash} />
                    <Text style={styles.cartaNomeClash}>{carta.nome}</Text>
                  </View>
                ))}
              </View>
            )}
          </Card>
        )}
      />

      <View style={{ marginTop: 15 }}>
        <TouchableOpacity style={styles.buttonClashLogout} onPress={logout}>
          <Text style={styles.buttonText}>SAIR (LOGOUT)</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ------------------- TELA DE CADASTRO -------------------
function Cadastro() {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');

  async function gravar() {
    if (!user || !password) {
      alert('Preencha os campos!');
      return;
    }
    try {
      await AsyncStorage.setItem(user, password);
      alert('Usuário criado com sucesso!');
      setUser('');
      setPassword('');
    } catch {
      alert('Erro ao cadastrar.');
    }
  }

  return (
    <View style={[styles.container, styles.loginBackground]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Image 
          source={{ uri: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/ee/Clash_Royale_logo.svg/1200px-Clash_Royale_logo.svg.png' }}
          style={styles.gameLogoSmall}
        />
        <View style={styles.loginCard}>
          <Text style={styles.loginTitle}>REGISTRAR NO ROYALE</Text>
          <Text style={styles.label}>NOVO NOME DE JOGADOR:</Text>
          <TextInput
            style={styles.inputClash}
            value={user}
            onChangeText={setUser}
            placeholder="Crie seu usuário..."
            placeholderTextColor="#a09070"
          />
          <Text style={styles.label}>NOVA SENHA SECRETA:</Text>
          <TextInput
            style={styles.inputClash}
            value={password}
            onChangeText={setPassword}
            placeholder="Crie sua senha..."
            placeholderTextColor="#a09070"
            secureTextEntry
          />
          <TouchableOpacity style={styles.buttonClashPrimary} onPress={gravar}>
            <Text style={styles.buttonText}>CADASTRAR NO CLAN</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

// ------------------- APP PRINCIPAL -------------------
export default function App() {
  const [logado, setLogado] = useState(false);

  useEffect(() => {
    const verificarLogin = async () => {
      const usuario = await AsyncStorage.getItem('usuarioLogado');
      if (usuario) setLogado(true);
    };
    verificarLogin();
  }, []);

  return (
    <NavigationContainer>
      {logado ? (
        // Se estiver logado -> mostra só a tela principal (sem tabs)
        <Principal />
      ) : (
        // Se não -> mostra login e cadastro com abas
        <Tab.Navigator
          screenOptions={({ route }) => ({
            headerShown: false,
            tabBarActiveTintColor: '#FFD700',
            tabBarInactiveTintColor: '#C0C0C0',
            tabBarStyle: styles.tabBarClash,
            tabBarLabelStyle: styles.tabBarLabelClash,
            tabBarIcon: ({ color, size }) => {
              let iconName = route.name === 'Login' ? 'sword-cross' : 'castle';
              return <MaterialCommunityIcons name={iconName} color={color} size={size} />;
            },
          })}
        >
          <Tab.Screen name="Login" component={Principal} options={{ title: 'Arena de Batalha' }} />
          <Tab.Screen name="Criar Usuário" component={Cadastro} options={{ title: 'Novo Recruta' }} />
        </Tab.Navigator>
      )}
    </NavigationContainer>
  );
}


// ------------------- ESTILOS CLASH ROYALE -------------------
const styles = StyleSheet.create({
  // --- Geral ---
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#303030', // Dark background for contrast
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  // --- Títulos/Textos ---
  tituloClash: {
    fontSize: 26,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 15,
    color: '#FFD700', // Gold/Yellow
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 3,
  },
  // --- Navegação ---
  headerClash: {
    backgroundColor: '#404040', // Dark header
  },
  headerTitleClash: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 20,
  },
  tabBarClash: {
    backgroundColor: '#404040', // Dark tab bar
    borderTopColor: '#FFD700', // Gold border top
    borderTopWidth: 2,
    height: 60,
  },
  tabBarLabelClash: {
    fontWeight: 'bold',
    fontSize: 12,
  },
  // --- Login/Cadastro ---
  loginBackground: {
    backgroundColor: '#5C4033', // Dark wood/earth tone
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameLogo: {
    width: 200,
    height: 50,
    resizeMode: 'contain',
    marginBottom: 30,
  },
  gameLogoSmall: {
    width: 150,
    height: 40,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  loginCard: {
    backgroundColor: 'rgba(50, 50, 50, 0.85)', // Semi-transparent dark card
    padding: 25,
    borderRadius: 15,
    width: '90%',
    maxWidth: 400,
    borderWidth: 3,
    borderColor: '#FFD700', // Gold border
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 8,
  },
  loginTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#FF6347', // Tomato Red
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  label: {
    color: '#FFD700',
    fontWeight: '600',
    marginTop: 10,
    marginBottom: 5,
  },
  inputClash: {
    backgroundColor: '#707070', // Grey input field
    color: '#fff',
    borderWidth: 2,
    borderColor: '#FFD700',
    padding: 10,
    marginVertical: 8,
    borderRadius: 8,
    fontSize: 16,
  },
  // --- Botões ---
  buttonClashPrimary: {
    backgroundColor: '#FF6347', // Primary Red button
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#FFA07A', // Lighter red border
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  buttonClashSecondary: {
    backgroundColor: '#4682B4', // Steel Blue secondary button
    padding: 8,
    borderRadius: 8,
    marginTop: 5,
    borderWidth: 1,
    borderColor: '#ADD8E6', // Light blue border
    alignSelf: 'flex-end',
  },
  buttonClashLogout: {
    backgroundColor: '#8B0000', // Dark Red/Maroon logout button
    padding: 12,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#FF4500', // Orange-Red border
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: '900',
    textAlign: 'center',
    fontSize: 16,
  },
  buttonTextSmall: {
    color: 'white',
    fontWeight: '700',
    textAlign: 'center',
    fontSize: 12,
  },
  // --- Decks e Cartas ---
  inputClashSearch: {
    backgroundColor: '#404040',
    color: '#fff',
    borderWidth: 1,
    borderColor: '#FFD700',
    padding: 10,
    marginVertical: 10,
    borderRadius: 20, // Rounded for search bar
    fontSize: 16,
    paddingLeft: 15,
  },
  cardClash: {
    marginVertical: 8,
    padding: 15,
    backgroundColor: '#5C4033', // Dark wood background for card
    borderWidth: 3,
    borderColor: '#7B3F00', // Darker wood border
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.6,
    shadowRadius: 5,
    elevation: 8,
  },
  deckContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  deckImgClash: {
    width: 60,
    height: 60,
    marginRight: 15,
    borderWidth: 2,
    borderColor: '#FFD700', // Gold border for main card image
    borderRadius: 5,
  },
  deckNomeClash: {
    flex: 1,
    fontSize: 18,
    fontWeight: '800',
    color: '#fff',
  },
  elixirIcon: {
    width: 20,
    height: 20,
    marginLeft: 10,
    marginRight: 2,
  },
  elixirText: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cartasContainer: {
    marginTop: 15,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.2)', // Light separator
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  carta: {
    alignItems: 'center',
    width: '24%', // Adjust width for 4 per row
    marginBottom: 10,
    padding: 2,
  },
  cartaImgClash: {
    width: 65,
    height: 65,
    borderRadius: 5,
    borderWidth: 1.5,
    borderColor: '#FFD700', // Gold border for card
    // Add a slight shadow to card image
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 1,
  },
  cartaNomeClash: {
    fontSize: 10,
    textAlign: 'center',
    color: '#fff',
    fontWeight: '600',
    marginTop: 3,
  },
});